package miProyecto;

import java.util.*;
import java.io.*;
import javax.swing.*;
/** 
	*se crea una clase de clasificación predeterminada que puede guardar y cargar
        */
public class Clasificacion
{
	private Map<Integer, ArrayList<String>> rank;
	private final File f;
	
	
	public Clasificacion()throws IOException
	{
		rank = new TreeMap<>();
		f = new File("ranking.dat");
		load();

	}
	/**

	 * Agrega una puntuación al TreeMap
	 *  score la puntuación para sumar
	 *  name el nombre del jugador
     * @param score
     * @param name
     * @throws java.io.IOException
	 */
	public void add(int score, String name)throws IOException
	{
		if(rank == null)
		{
			rank = new TreeMap<>();
			System.out.println (1);
		}
		if(rank.containsKey(score))
		{
			rank.get(score).add(name);
		}
		else
		{
			ArrayList<String> names = new ArrayList<>();
			names.add(name);
			rank.put(score, names);
		}
		
	}
	/**
	 *  fileName el nombre del archivo para guardar
     * @throws java.io.IOException
	 */
	public void save()throws IOException
	{
			
			try
	    	{
                            try (PrintWriter out = new PrintWriter(f)) {
                                if(!rank.isEmpty())
                                    rank.keySet().stream().map((i) -> {
                                        out.println(i);
                                    return i;
                                }).forEachOrdered((i) -> {
                                    for(int a = 0; a < rank.get(i).size(); a++)
                                    {
                                        out.println(rank.get(i).get(a));
                                    }
                                });
                            }

	    	}
	    	catch(IOException exception)
	    	{
	    		System.out.println("File problem - could not save");
	    	}
		
  
	}
	/**
	 file el nombre del archivo para guardar
	 */
	private void load()throws IOException
	{
            try (Scanner in = new Scanner(f)) {
                int a = 0;
                ArrayList<String> names = null;
                while(in.hasNextLine())
                {
                    
                    if(in.hasNextInt())
                    {
                        if(names != null)
                        {
                            rank.put(a, names);
                        }
                        a = in.nextInt();
                        in.nextLine();
                        names = new ArrayList<>();
                    }
                    else
                    {
                        String name = in.nextLine();
                        names.add(name);
                    }
                    
                }
                rank.put(a,names);
            }
	}
	/**
	 * Da una representación de cadena del TreeSet
        * la representación de la cadena
     * @return 
	 */
	public String toString()
	{
		String s = "";
		if(!rank.isEmpty())
		for(int i : rank.keySet())
		{			
			for(int a = 0; a < rank.get(i).size(); a++)
			{
				s = i + "\t\t" + rank.get(i).get(a) + "\n" + s;
			}
			
		}
		return "SCORE\t\tPLAYERS\n" + s;
	}
}
	