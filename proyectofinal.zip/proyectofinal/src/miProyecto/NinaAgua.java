package miProyecto;

import java.io.File;
import java.net.URL;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;


public class NinaAgua extends EnMovimiento
{

	private Image image;

	public NinaAgua()
	{
		this(700, 400,50,50,1);
		
	}

	/**
            Construye una niña en un lugar específico con un determinado
           * velocidad, ancho y alto.
           * @param x la ubicación x
           * @param y la ubicación y
           * @param con el ancho
           * @param h la altura
           * @param es la velocidad
*/
	public NinaAgua(int x, int y, int w, int h, int s)
	{
		super(x, y, w, h);
		setSpeed(s);
		try
		{
			URL url = getClass().getResource("watergirl.png");
			image = ImageIO.read(url);
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,"Image was not found !");
		}
	}

	
		
	
	public void move(String direction)
	{
	
		if(direction.equalsIgnoreCase("LEFT"))
			setX(getX()- getSpeed());
		if(direction.equalsIgnoreCase("RIGHT"))
			setX(getX()+ getSpeed());
		if(direction.equalsIgnoreCase("UP"))
		{
			setY(getY()- getSpeed());	
		}
		if(direction.equalsIgnoreCase("DOWN"))
			setY(getY()+ getSpeed());
	}

	
	public void draw(Graphics window)
	{
 		window.drawImage(image,getX(),getY(),getWidth(),getHeight(),null);
	}


	public String toString()
	{
		return super.toString() + getSpeed();
	}
}