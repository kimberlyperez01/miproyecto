package miProyecto;

import java.io.File;
import java.net.URL;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.ArrayList;
/**
* Administra los niveles y construye todos los elementos del nivel utilizando imágenes y archivos de datos
*/
public class Grama
{
	
	private LinkedList<int[][]> lvl;
	private Image grass;
	private Image back;
	private int [][] grassOn;
	public final static int SIZE = 30;
	private Image lava, water, poison, rGem, bGem, comp, wall;
	private NinoFuego boy;
	private NinaAgua girl;
	private Rocas stone;
	private int score;
	private int lvlNum;
	/**
	* Crea un objeto Grama predeterminado que usa los archivos de datos y el
        * las imágenes están preseleccionadas para diferentes tipos de objetos*/
	
        public Grama()throws FileNotFoundException
	{
		score = 0;
			
		lvl = new LinkedList<int[][]>();
		boy = new NinoFuego();
		girl = new NinaAgua();
		stone = new Rocas();
		changeStage("lvl1.txt");
		grassOn = lvl.get(0);
		lvlNum = 0;
	
		try
		{
			URL url = getClass().getResource("azulejo_hierba_1.jpg");
			grass = ImageIO.read(url);
			System.out.println("grama encontrado");
			URL url2 = getClass().getResource("Frosting_Forest_background.png");
			System.out.println("Fondo Encontrado");
			back = ImageIO.read(url2);
			URL url3 = getClass().getResource("Lava.jpg");
			System.out.println("Lava found");
			lava = ImageIO.read(url3);
			URL url4 = getClass().getResource("agua.jpg");
			System.out.println("Water found");
			water = ImageIO.read(url4);
			URL url5 = getClass().getResource("verde.jpg");
			System.out.println("poison found");
			poison = ImageIO.read(url5);
			URL url6 = getClass().getResource("redgem.png");
			System.out.println("red gem found");
			rGem = ImageIO.read(url6);
			URL url7 = getClass().getResource("diamante.png");
			System.out.println("Gema azul encontrada");
			bGem = ImageIO.read(url7);
			URL url8 = getClass().getResource("url.jpg");
			System.out.println("url found");
			comp = ImageIO.read(url8);
			URL url9 = getClass().getResource("wall.jpg");
			System.out.println("wall found");
			wall = ImageIO.read(url9);

		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,"Imagen no encontrada!");
		}
	}
	/**
	* posicion
	*  x la posicion de x
	*  y la posicion de y
	* value la cantidad de cambio la posición
	*/
	public void changePostion(int x, int y, int value)
	{
		grassOn[y/SIZE+1][x/SIZE+1] = value;
		grassOn[y/SIZE][x/SIZE] = value;
		grassOn[y/SIZE-1][x/SIZE+1] = value;

	}
                /**	
        * Cambia el nivel que muestra el objeto Stage
        * archivo @param el nuevo diseño del nivel
        */
	public void changeStage(String file) throws FileNotFoundException
	{
		Scanner in = new Scanner(new File(file));
		int x = 0;
		int lvlNum = in.nextInt();
		in.nextLine();
		int [] [] temp = new int[20][26];
		for(int c = 0; c < lvlNum; c++)
		{
			
			for(int b = 0; b< 19; b++)
			{
				String line = in.nextLine();
				String[] lin = line.split(" ");
				
				for(int a = 0; a < lin.length; a++)
				{
					temp[x][a] = Integer.parseInt(lin[a]);

				}

				x++;
			}
			
			lvl.add(temp);
			temp = new int[20][26];
			x= 0;
		}
	}

	public void setLvl(int a)
	{
			
			grassOn = lvl.get(lvl.indexOf(grassOn)+1 + a);
			boy.setPos(0,400);
			girl.setPos(710,400);
		
	}
	/**
* Devuelve qué nivel es el nivel actual que se muestra
*/
	public int getLvlNum()
	{
		return lvl.indexOf(grassOn)+1;
	}

	public void changeScore(int a)
	{
		score +=a;
	}

	public void draw(Graphics window) 
	{
		window.drawImage(back,0,0,800,600,null);
		
		for(int a = 0; a < grassOn.length; a++)
		{
			for(int b = 0; b < grassOn[a].length; b++)
			{
				if(grassOn[a][b] == -2)
				{
					stone.setPos(b*SIZE, a*SIZE);
					grassOn[a][b] = 0;
		
				}
				else if (grassOn[a][b] == 1 || grassOn[a][b] == -1)
				{
					window.drawImage(grass, b*SIZE, a*SIZE, SIZE,SIZE,null);
				}

				else if (grassOn[a][b] == 2 || grassOn[a][b] == 3)
				{
					window.drawImage(comp, b*SIZE, a*SIZE, SIZE,SIZE,null);
				}
				else if (grassOn[a][b] == 4)
				{
					window.drawImage(lava, b*SIZE, a*SIZE, SIZE,SIZE,null);
				}
				else if (grassOn[a][b] == 12 || grassOn[a][b] ==13 || grassOn[a][b] == -11)
				{
					window.drawImage(wall, b*SIZE, a*SIZE, SIZE,SIZE,null);
				}
				else if (grassOn[a][b] == 5)
				{
					window.drawImage(water, b*SIZE, a*SIZE, SIZE,SIZE,null);
				}
				else if (grassOn[a][b] == 6)
				{
					window.drawImage(poison, b*SIZE, a*SIZE, SIZE,SIZE,null);
				}
				else if (grassOn[a][b] == 7)
				{
					window.drawImage(rGem, b*SIZE, a*SIZE, SIZE,SIZE,null);
				}
				else if (grassOn[a][b] == 8)
				{
					window.drawImage(bGem, b*SIZE, a*SIZE, SIZE,SIZE,null);
				}
				else 
				{
				}
			window.drawString("Total Score: " + score, 600,35);
			}
			
		}
	}
	
	public int getHeadLeft(EnMovimiento o)
	{
		int x = o.getX() / SIZE;
		int y = o.getY() / SIZE;
		return grassOn[y][x];
	}
	
	public int getHeadRight(EnMovimiento o)
	{
		int x = (o.getX() + o.getWidth())/ SIZE;
		int y = o.getY() / SIZE;
		return grassOn[y][x];
	}
	
	public int getCenterLeft(EnMovimiento o)
	{
		int x = o.getX() / SIZE;
		int y = (o.getY() + o.getHeight() /2) / SIZE;
		return grassOn[y][x];
	}
	
	public int getCenter(EnMovimiento o)
	{
		int x = (o.getX() + o.getWidth()/2)/ SIZE;
		int y = (o.getY() + o.getHeight()/2 ) / SIZE;
		return grassOn[y][x];
	}

	public int getCenterRight(EnMovimiento o)
	{
		int x = (o.getX() + o.getWidth())/ SIZE;
		int y = (o.getY() + o.getHeight()/2 ) / SIZE;
		return grassOn[y][x];
	}

	public int getBottomLeft(EnMovimiento o)
	{
		int x = o.getX() / SIZE;
		int y = (o.getY() + o.getHeight()) / SIZE;
		return grassOn[y][x];
	}

	public int getBottomRight(EnMovimiento o)
	{
		int x = (o.getX() + o.getWidth())/ SIZE;
		int y = (o.getY() + o.getHeight()) / SIZE ;
		return grassOn[y][x];
	}

	public int getBottomMidOne(EnMovimiento o)
	{
		int x = (o.getX() + (2 * o.getWidth()/ 5))/ SIZE;
		int y = (o.getY() + o.getHeight()) / SIZE ;
		return grassOn[y][x];
	}

	public int getBottomMidTwo(EnMovimiento o)
	{
		int x = (o.getX() + (o.getWidth() - ((2 * o.getWidth())/5)))/ SIZE;
		int y = (o.getY() + o.getHeight()) / SIZE ;
		return grassOn[y][x];
	}
	
	public int getBottomMidThree(EnMovimiento o)
	{
		int x = (o.getX() + (2 * o.getWidth()/ 7))/ SIZE;
		int y = (o.getY() + o.getHeight()) / SIZE ;
		return grassOn[y][x];
	}

	public int getBottomMidFour(EnMovimiento o)
	{
		int x = (o.getX() + (o.getWidth() - ((2 * o.getWidth())/7)))/ SIZE;
		int y = (o.getY() + o.getHeight()) / SIZE ;
		return grassOn[y][x];
	}

	public void comp(EnMovimiento o)
	{

		int x = (o.getX() + (2 * o.getWidth()/ 5))/ SIZE;
		int y = (o.getY() + o.getHeight()) / SIZE ;
		if(grassOn[y][x] == 2)
		{
			grassOn[y][x] = 0;
			boolean more = false;
			for(int r = 0; r < grassOn.length; r++)
				for(int c = 0; c < grassOn[r].length;c++)
				{
					if(grassOn[r][c] == 2)
						more = true;
				}
			if(!more)
			for(int r = 0; r < grassOn.length; r++)
				for(int c = 0; c < grassOn[r].length;c++)
				{
					if(grassOn[r][c] == 12)
						grassOn[r][c] = 0;
				}
			
		}	
		if(grassOn[y][x] == 3)
		{
			grassOn[y][x] = 0;
			boolean more = false;
			for(int r = 0; r < grassOn.length; r++)
				for(int c = 0; c < grassOn[r].length;c++)
				{
					if(grassOn[r][c] == 3)
						more = true;
				}
			if(!more)
			for(int r = 0; r < grassOn.length; r++)
				for(int c = 0; c < grassOn[r].length;c++)
				{
					if(grassOn[r][c] == 13)
						grassOn[r][c] = 0;
				}
		}
		
	}
	
	public void hiddenSwitch(EnMovimiento o)
	{
		int x = (o.getX() + o.getWidth()) / SIZE; int y = (o.getY()+ o.getHeight()) / SIZE;

		if(y >= 0 && x >= 0)
			if(grassOn[y][x] == -1)
			{
				for(int r = 0; r < grassOn.length; r++)
					for(int c = 0; c < grassOn[r].length;c++)
					{
						if(grassOn[r][c] == -11)
							grassOn[r][c] = 0;
					}
			}
}
	public boolean isThereGrass(EnMovimiento o)
	{
		int x1 = (int)Math.ceil(o.getX() / SIZE);
		int x2 = (int)Math.ceil((o.getX() + SIZE) / SIZE);
		int head = (int)Math.ceil(o.getY() / SIZE );
		int foot = (int)Math.ceil((o.getY() + SIZE) / SIZE);
		return grassOn[head][x1] == 1 || grassOn[foot][x2] == 1; 
	} 
	/**
* Obtiene la puntuación del juego
* retorna el número que está allí, que representa qué objeto/imagen está en esa posición
*/
	public int getScore()
	{
		return score;
	}
	/**
	Elimina la gema dada */
        
	public void gem(int whichGem)
	{
		for(int r = 0; r < grassOn.length; r++)
			for(int c = 0; c < grassOn[r].length;c++)
			{
				if(grassOn[r][c] == whichGem)
					grassOn[r][c] = 0;
			}
	}
	/**
	 * obtner niño fuego
	 */
	public NinoFuego getFireBoy()
	{
		return boy;
	}
	/**
	 * obtener niña agua
         */
	public NinaAgua getWaterGirl()
	{
		return girl;
	}
//obtener roca
	public Rocas getBoulder()
	{
		return stone;
	}
}