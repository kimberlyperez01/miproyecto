package miProyecto;

import java.io.File;
import java.net.URL;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import java.io.FileNotFoundException;

public class Rocas extends EnMovimiento
{

	private Image image;

	/**
* Construye una roca con una ubicación de (10,10), un ancho
* altura y velocidad de 10
*/
	public Rocas()
	{
		this(740,10,30,30,1);
		setSpeed(1);
	}




	/**
	* Construye una roca en un lugar específico con una determinada
        * velocidad, ancho y alto.
        *  x la ubicación x
        *  y la ubicación y
        *  con el ancho
        *  h la altura
        * es la velocidad
	 */
	public Rocas(int x, int y, int w, int h, int s)
	{
		super(x, y, w, h);
		setSpeed(s);
		try
		{
			URL url = getClass().getResource("piedra.jpg");
			image = ImageIO.read(url);
		}
		catch(Exception e)
		{
			//feel free to do something here
			JOptionPane.showMessageDialog(null,"Image was not found!");
		}
	}

	
	public void move(String direction)
	{
		if(direction.equalsIgnoreCase("LEFT"))
			setX(getX()- getSpeed());
		if(direction.equalsIgnoreCase("RIGHT"))
			setX(getX()+ getSpeed());
		if(direction.equalsIgnoreCase("UP"))
			setY(getY()- getSpeed());
		if(direction.equalsIgnoreCase("DOWN"))
			setY(getY()+ getSpeed());
	}


	public void draw(Graphics window)
	{
		if(getX()<780)
 		window.drawImage(image,getX(),getY(),getWidth(),getHeight(),null);
	}

	
	public String toString()
	{
		return super.toString() + getSpeed();
	}
}
