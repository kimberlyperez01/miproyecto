
package miProyecto;

import java.io.IOException;


public class Proyecto {

    public static void main(String[] args) throws IOException {
        Ensayador t = new Ensayador();
    }
}
